
package com.loan.registerloan.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.loan.registerloan.models.RegisterLoanDetail;
import com.loan.registerloan.models.RegisterLoanResponse;

@SpringBootTest
public class RegisterLoanServiceTest {

	@Test
	public void registerLoanTestForNoRecords() throws SQLException, IOException {
		java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
		Random rand = new Random();
		int loanid = rand.nextInt(1000) + 1;
		RegisterLoanDetail loanDetails = new RegisterLoanDetail();
		loanDetails.setDuration("2months");
		loanDetails.setUser_name("xyz");
		loanDetails.setLoan_amount("2lacks");
		loanDetails.setLoan_type("house");
		loanDetails.setRateofint("12");
		loanDetails.setUpdatedby("venkatareddy");
		loanDetails.setUpdatedat(date);
		loanDetails.setLoanid(loanid);
		RegisterLoanService service = new RegisterLoanService();
		RegisterLoanResponse registerLoan = service.RegisterLoan(loanDetails);
		assertEquals("Customer Does not Exixts", registerLoan.getMessage());
	}

}
