package com.Customer.Registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class CustomerRegistrationApplication {

	private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationApplication.class);

	public static void main(String[] args) {

		LOGGER.info("The CustomerRegistrationApplication app");
		LOGGER.debug("Debug level log message");
		LOGGER.error("Error level log message");

		SpringApplication.run(CustomerRegistrationApplication.class, args);
	}
}
