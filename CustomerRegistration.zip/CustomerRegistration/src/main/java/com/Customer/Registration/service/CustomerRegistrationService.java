package com.Customer.Registration.service;

import com.Customer.Registration.models.CustomerRegistrationResponse;
import com.Customer.Registration.CustomerRegistrationApplication;
import com.Customer.Registration.models.CustomerRegistrationDetail;
/*import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.LOGGER;*/

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
public class CustomerRegistrationService {

	
	@Autowired
	private CustomerRegistrationResponse CustomerRegistrationResponse;

	
	
	
	private static final Logger LOGGER = LogManager.getLogger(CustomerRegistrationService.class);
	
	
	public Connection DBconnection() throws IOException {
		
		Properties props = new Properties();
		FileInputStream in = new FileInputStream("src/main/resources/application.properties");
		props.load(in);
		in.close();
		Connection con = null;
		String url = props.getProperty("spring.datasource.url");
		String username = props.getProperty("spring.datasource.username");
		String password = props.getProperty("spring.datasource.password");
		
		try {
			con = DriverManager.getConnection(url, username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
		
	}

	public CustomerRegistrationResponse Login(CustomerRegistrationDetail Customer_Dtl) throws SQLException, IOException {
		LOGGER.info("CustomerRegistration : Inside Customer Registration Login Service");

		boolean Flag = true;
		if ((Customer_Dtl.getUser_name()).length() == 0) {
			LOGGER.info("CustomerRegistration : user name cannot be blank");
			CustomerRegistrationResponse.setMessage("user name cannot be blank");
			Flag = false;
		} else if ((Customer_Dtl.getPassword()).length() == 0) {
			LOGGER.info("CustomerRegistration : password cannot be blank");
			CustomerRegistrationResponse.setMessage("password  cannot be blank");
			Flag = false;
		}

		if (Flag == true) {

		String check_query = "select count(*) from Customer_Dtl where user_name = ? and password = ? ";
		Connection con = DBconnection();
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodb?useSSL=false", "root", "pass@word1");
		java.sql.PreparedStatement preparedStmt = con.prepareStatement(check_query);
		preparedStmt.setString(1, Customer_Dtl.getUser_name());
		preparedStmt.setString(2, Customer_Dtl.getPassword());
		ResultSet rs = preparedStmt.executeQuery();
		int n = 0;
		if (rs.next()) {
			n = rs.getInt(1);
		}

		if (n > 0) {
			LOGGER.info("CustomerRegistration : Login successful");
			CustomerRegistrationResponse.setMessage("Login successful");
		} else {
			LOGGER.info("CustomerRegistration : Invalid user Credentials");
			CustomerRegistrationResponse.setMessage("Invalid User Credentials");
		}
		}
		return CustomerRegistrationResponse;

	}

	public CustomerRegistrationResponse Registration(CustomerRegistrationDetail Customer_Dtl) throws SQLException, IOException {
		LOGGER.info("CustomerRegistration : Inside Customer Registration Login Service");
		boolean Flag = true;

		if ((Customer_Dtl.getUser_name()).length() == 0) {
			LOGGER.info("CustomerRegistration : user name cannot be blank");
			CustomerRegistrationResponse.setMessage("user name cannot be blank");
			Flag = false;
		} else if ((Customer_Dtl.getFirst_name()).length() == 0) {
			LOGGER.info("CustomerRegistration : customer name cannot be blank");
			CustomerRegistrationResponse.setMessage("customer name cannot be blank");
			Flag = false;
		} else if ((Customer_Dtl.getEmail()).length() == 0) {
			LOGGER.info("CustomerRegistration : email cannot be blank");
			CustomerRegistrationResponse.setMessage("Email cannot be blank");
			Flag = false;
		} else if ((Customer_Dtl.getPan()).length() == 0) {
			LOGGER.info("CustomerRegistration : PAN cannot be blank");
			CustomerRegistrationResponse.setMessage("PAN cannot be blank");
			Flag = false;
		} else if ((Customer_Dtl.getDob()).length() == 0) {
			LOGGER.info("CustomerRegistration : DOB cannot be blank");
			CustomerRegistrationResponse.setMessage("DOB cannot be blank");
			Flag = false;
		} else if ((Customer_Dtl.getPassword()).length() == 0) {
			LOGGER.info("CustomerRegistration : password cannot be blank");
			CustomerRegistrationResponse.setMessage("password cannot be blank");
			Flag = false;
		}

		if (Flag == true) {
			try {
				

				String query = " insert into Customer_Dtl (user_name, first_name, address, email, pan, dob, password, updatedby, updatedat)"
						+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

				// create the mysql insert preparedstatement
				Connection con = DBconnection();
				
				java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
				java.sql.PreparedStatement preparedStmt = con.prepareStatement(query);
				preparedStmt.setString(1, Customer_Dtl.getUser_name());
				preparedStmt.setString(2, Customer_Dtl.getFirst_name());
				preparedStmt.setString(3, Customer_Dtl.getAddress());
				preparedStmt.setString(4, Customer_Dtl.getEmail());
				preparedStmt.setString(5, Customer_Dtl.getPan());
				preparedStmt.setString(6, Customer_Dtl.getDob());
				preparedStmt.setString(7, Customer_Dtl.getPassword());
				preparedStmt.setString(8, Customer_Dtl.getUser_name());
				preparedStmt.setTimestamp(9, date);

				try {
					preparedStmt.execute();
					LOGGER.info("CustomerRegistration : The cutomer detail is registered");
					CustomerRegistrationResponse.setMessage("The cutomer detail is registered successful");
				} catch (SQLException e) {
					LOGGER.info("CustomerRegistration : This customer already exists");
					CustomerRegistrationResponse.setMessage("This customer already exists");

				}
				con.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LOGGER.info("CustomerRegistration:exception :: " +e);
				e.printStackTrace();
			}

		}
		return CustomerRegistrationResponse;
	}

}
