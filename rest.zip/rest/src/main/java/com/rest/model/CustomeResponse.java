package com.rest.model;

import org.springframework.stereotype.Component;

@Component
public class CustomeResponse {
	private String username;
	private String firstname;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	

}
