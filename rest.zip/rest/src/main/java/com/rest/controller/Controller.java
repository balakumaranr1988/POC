package com.rest.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.model.User;
import com.rest.model.CustomeResponse;;

@RestController
public class Controller {
	
	@Autowired
	public CustomeResponse CustomeResponse;
	private static final Logger log = LoggerFactory.getLogger(Controller.class);

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	
	  public CustomeResponse login(@RequestBody User userinp) throws Exception
	  { System.out.println("username" + userinp.getUserName());
	  System.out.println("Firstname" + userinp.getFirstName()); 
	  CustomeResponse.setUsername(userinp.getUserName());
	  CustomeResponse.setFirstname(userinp.getFirstName());
	  
	  return CustomeResponse;
	  
	  }
	 ;
	@RequestMapping(value = "/registration", method = RequestMethod.POST, produces = MediaType.TEXT_PLAIN_VALUE)

	public @ResponseBody ResponseEntity<String> addUser(@RequestParam String name, @RequestParam String email) {
		String input = name;
		return new ResponseEntity<String>(input, HttpStatus.OK);
	}
}
